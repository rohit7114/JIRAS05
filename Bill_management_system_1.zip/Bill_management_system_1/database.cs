﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bill_management_system_1
{
    public static class database
    {
       public static string connectionString = "server=MSI\\SQLEXPRESS03;database=bill_management_system;integrated Security= SSPI;";
    }
}
