﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Bill_management_system_1
{
    public partial class Inventory : Form
    {
        public Inventory()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Inventory_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string product_id;
            string product_name;
            int price;
            string company_name;
            string stock;
            DateTime mdate;
            DateTime exdate;

            product_id = textBox1.Text;
            product_name = textBox2.Text;
            price = Convert.ToInt32(textBox3.Text);
            company_name = textBox4.Text;
            stock = textBox5.Text;
            mdate = dateTimePicker1.Value;
            exdate = dateTimePicker2.Value;
            string connectionString = database.connectionString;
            //string connectionString = "server=MSI\\SQLEXPRESS03;database=bill_management_system;integrated Security= SSPI;";
            using (SqlConnection _con = new SqlConnection(connectionString))
            {
                string queryStatement = "INSERT INTO product_1 (  P_name , P_price , P_company , P_man , P_expiry , stock_quantity) VALUES (  @P_name , @P_price , @P_company , @P_man , @P_expiry , @stock_quantity)";

                using (SqlCommand _cmd = new SqlCommand(queryStatement, _con))
                {

                    _cmd.Parameters.AddWithValue("@P_name ", product_name);
                    _cmd.Parameters.AddWithValue("@P_price ", price);
                    _cmd.Parameters.AddWithValue("@P_company ", company_name);
                    _cmd.Parameters.AddWithValue("@P_man ", mdate);
                    _cmd.Parameters.AddWithValue("@P_expiry ", exdate);
                    _cmd.Parameters.AddWithValue("@stock_quantity ", stock);


                    SqlDataAdapter _dap = new SqlDataAdapter(_cmd);

                    _con.Open();
                    int isWorking = _cmd.ExecuteNonQuery();

                    _con.Close();

                    if (isWorking == 1)
                    {
                        MessageBox.Show("product insert successfully");
                    }
                    else
                    {
                        MessageBox.Show("invalid attempt");
                    }




                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = String.Empty;
            textBox2.Text = String.Empty;
            textBox3.Text = String.Empty;
            textBox4.Text = String.Empty;
            textBox5.Text = String.Empty;
            dateTimePicker1.Text = String.Empty;
            dateTimePicker2.Text = String.Empty;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }
    }
}
