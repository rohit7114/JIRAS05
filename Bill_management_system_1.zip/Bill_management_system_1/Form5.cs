﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bill_management_system_1
{
    public partial class Form5 : Form
    {
        private DataTable billData;
        public Form5(DataTable dt)
        {
            InitializeComponent();
            billData = dt;
            LoadBillData();
        }

            private void LoadBillData()
        {
            dataGridView1.DataSource = billData;

            decimal totalAmount = 0;

            foreach (DataRow row in billData.Rows)
            {
                totalAmount += Convert.ToDecimal(row["TotalPrice"]);
            }

            label1.Text = $"Total Amount: {totalAmount:C}";
        }

        private void FinalBill_Load(object sender, EventArgs e)
        {

        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
