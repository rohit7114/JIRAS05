﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Bill_management_system_1
{
    public partial class Bill : Form
    {

        DataTable dt = new DataTable();



        public Bill()
        {
            InitializeComponent();
            dt.Columns.Add("ProductId");
            dt.Columns.Add("Quanity");
            dt.Columns.Add("P_name");
            dt.Columns.Add("P_price");
            dt.Columns.Add("TotalPrice");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string product_id = textBox1.Text.Trim();
            int quantity = Convert.ToInt16(textBox2.Text);




            if (!int.TryParse(textBox2.Text, out quantity))
            {
                MessageBox.Show("Please enter a valid quantity.");
                return;
            }
            string connectionString = database.connectionString;
            //string connectionString = "server=MSI\\SQLEXPRESS03;database=bill_management_system;Integrated Security=SSPI;";

            using (SqlConnection _con = new SqlConnection(connectionString))
            {
                string queryStatement = "SELECT  P_name, P_price FROM product_1 WHERE P_id = @ProductId";

                using (SqlCommand _cmd = new SqlCommand(queryStatement, _con))
                {

                    _cmd.Parameters.AddWithValue("@ProductId", product_id);

                    try
                    {

                        SqlDataAdapter _dap = new SqlDataAdapter(_cmd);
                        DataTable prod = new DataTable();
                        prod.Columns.Add("P_name");
                        prod.Columns.Add("P_price");
                        _con.Open();
                        _dap.Fill(prod);
                        foreach (DataRow row in prod.Rows)
                        {
                            decimal price = Convert.ToDecimal(row["P_price"]);
                            decimal totalPrice = price * quantity;

                            dt.Rows.Add(product_id, quantity, row["P_name"], row["P_price"], totalPrice);
                        }

                        dataGridView1.DataSource = dt;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }
                    finally
                    {
                        _con.Close();
                    }
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = String.Empty;
            textBox2.Text = String.Empty;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Bill_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {

                int selectedIndex = dataGridView1.SelectedRows[0].Index;


                dt.Rows[selectedIndex].Delete();


                dataGridView1.DataSource = dt;

                MessageBox.Show("Selected row deleted successfully.");
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("No items to process.");
                return;
            }

            string connectionString = database.connectionString;

            using (SqlConnection _con = new SqlConnection(connectionString))
            {


                _con.Open();
                foreach (DataRow row in dt.Rows)
                {
                    string product_id = row["ProductId"].ToString();
                    int quantity = Convert.ToInt32(row["Quanity"]);

                    string updateQuery = "UPDATE product_1 SET stock_quantity = stock_quantity - @Quantity WHERE P_id = @ProductId";

                    using (SqlCommand _cmd = new SqlCommand(updateQuery, _con))
                    {
                        _cmd.Parameters.AddWithValue("@ProductId", product_id);
                        _cmd.Parameters.AddWithValue("@Quantity", quantity);

                        int rowsAffected = _cmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            MessageBox.Show($"Failed to update product with ID: {product_id}. Ensure the product exists and has enough stock.");
                        }
                        else
                        {
                            MessageBox.Show("Inventory updated successfully.");
                        }
                    }
                }
                _con.Close();
                Form5 f5 = new Form5(dt);
                f5.Show();
                this.Hide();
            }
        }
    }
}


    



